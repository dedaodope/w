const daftarvip = (prefix) => { 
	return `
	
───▄████▄─────
──███▄█▀──────
─▐████──█──█──
──█████▄──────
───▀████▀─────
}
exports.daftarvip = daftarvip
