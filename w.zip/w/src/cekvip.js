const cekvip = () => { 
	return `           
──────────────────
*Nome do bot* :  【Gustavo】𝑩𝑶𝑻
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *ATIVO*
────────────────── 
*Status Bot:* *Online*
──────────────────

*AÍ SIM PAE, VOCÊ É UM MEMBRO VIP😎✋`
}
exports.cekvip = cekvip
